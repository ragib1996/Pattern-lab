import numpy as np

w = np.array([0.5,0.5, 0.5])

yata = 0.01

def weight_change(p, actual , result):


    for i in range(0, len(p)):
       w[i] = w[i] + yata * (actual-result) * p[i]
       #print(w[i])


    return  w

def unitStep(v):
    if v >= 0:
        return 1
    else:
        return 0


# design Perceptron Model
def perceptronModel(p, w):
    v = np.dot(p, w)
    #print(v)
    y = unitStep(v)
    #print(y)
    return y


def f(x, expected):


    epoch = 1
    print("Epoch ", epoch)
    flag =  0
    while(1):

       for i in range(0 , len(x)):
          flag = 0
          result = perceptronModel(x[i], w)
          while( expected[i] != result):
              if flag == 0:
                print("weight ", w, " input ", x[i][1], " ", x[i][2], " expected ", expected[i], " result found ", result)
              flag = 1
              a = weight_change( x[i], expected[i], result)
              #print("Changed weight ", a)
              result = perceptronModel(x[i], w)
              epoch = epoch+1
              print("epoch ", epoch)
              print("weight ", w, " input ", x[i][1]," ",x[i][2], " expected ", expected[i], " result found ", result)

          if flag == 1:
              break
          print( "weight ",w, " input ",x[i][1]," ",x[i][2]," expected ",expected[i]," result found ", result)

       if i + 1 == len(x) and flag == 0:
           print("training finished.")
           break


def testing(x1, x2):

    input = [x1, x2]
    x = []
    x.append(1)
    for i in range(0, len(input)):
        x.append(input[i])
    ans = perceptronModel(x , w)
    print("Input ", input, " Output ",ans)



def training(input, output):
   x = []
   expected = []
   a = []

   for i in range(0, len(input)):
       a.append(1)

       b = input.iloc[i]
       b = np.array(b)
       for j in range(0, len(b)):
           a.append(b[j])

       x.append(np.array(a))
       a = []

       expected.append(output[i])





   f(x , expected )


