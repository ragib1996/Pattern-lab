import Perception_convergence_NAND
import pandas as pd
import numpy as np

csv_reader = pd.read_csv('input.csv')

x = []
output = []
for i in range(0, len(csv_reader)):
  t = csv_reader.iloc[i]
  t = np.array(t)
  a = []

  for j in range(0, len(t) - 1):
      a.append(t[j])

  x.append(a)
  output.append(t[len(t) - 1])

x = pd.DataFrame(x)

Perception_convergence_NAND.training(x, output)




Perception_convergence_NAND.testing(0,0 )
Perception_convergence_NAND.testing(0,1 )
Perception_convergence_NAND.testing(1,0 )
Perception_convergence_NAND.testing(1,1 )

